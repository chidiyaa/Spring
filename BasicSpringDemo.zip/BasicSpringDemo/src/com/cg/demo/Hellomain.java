package com.cg.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class Hellomain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ClassPathXmlApplicationContext factory=new ClassPathXmlApplicationContext("anno.xml");
		//HelloBean bean =(HelloBean) factory.getBean("hBean");
		//System.out.println(bean.helloWorld());
		/*
		Address myAdd=(Address) factory.getBean("address");
		System.out.println(myAdd);*/
		Employee emp=factory.getBean(Employee.class);
		System.out.println(emp);

	}

}
