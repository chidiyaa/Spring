package com.cg.mpa.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="purchasedetails")
public class PurchaseDetails {
	@Id
	@Column(name="purchaseid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_purchase_id",allocationSize=1)
	private Integer purchaseid;
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-z][a-zA-Z]{3,15}",message="Name should contain letters only and size should be netween 3 to 15 letters")
	@Column(name="cname")
	private String custName;
	@Column(name="phoneno")
	@NotNull(message="phone no is required")
	@Pattern(regexp="[0-9]{10}",message="Phone should contain 10 digits")
	private String phoneNo;
	@Column(name="mailid")
	@Email(message="Enter valid mailid ")
	private String emailId;
	@Column(name="purchaseDate")
	@Pattern(regexp="[0-9]{2}-[A-Za-z]{3}-[0-9]{4}",message="Date must be in dd-mm-yyyy")
	private String purchaseDate;
	@Column(name="mobileid")
	private Integer mobileId;
	public Integer getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(Integer purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Integer getMobileId() {
		return mobileId;
	}
	public void setMobileId(Integer mobileId) {
		this.mobileId = mobileId;
	}
	public PurchaseDetails(Integer purchaseid, String custName, String phoneNo,
			String emailId, String purchaseDate, Integer mobileId) {
		super();
		this.purchaseid = purchaseid;
		this.custName = custName;
		this.phoneNo = phoneNo;
		this.emailId = emailId;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	public PurchaseDetails() {
		super();
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseid=" + purchaseid + ", custName="
				+ custName + ", phoneNo=" + phoneNo + ", emailId=" + emailId
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
	
	

}
