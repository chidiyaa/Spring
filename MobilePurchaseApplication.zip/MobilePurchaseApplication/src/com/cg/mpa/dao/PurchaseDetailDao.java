package com.cg.mpa.dao;

import com.cg.mpa.entities.PurchaseDetails;

public interface PurchaseDetailDao {
	void insertPurchaseDetails(PurchaseDetails pdetails);

}
